# Skinet Udemy Course repository

This is the updated repository for the .Net 7.0, Angular 15 and Bootstrap 5 version of the course refreshed as at January 2023

View a demo of this app [here](https://skinet.trycatchlearn.com).  

You can see how this app was made by checking out the Udemy course for this here (with discount)

[Udemy course](https://www.udemy.com/course/learn-to-build-an-e-commerce-app-with-net-core-and-angular/?couponCode=DEF89B3169FF2B609AD8)

If you are looking for the repository for the version of this app created on .Net 6.0 and Angular v12 then this is available here:

https://github.com/TryCatchLearn/Skinet-v6
