export const environment = {
    production: true,
    apiUrl: 'api/'
  };